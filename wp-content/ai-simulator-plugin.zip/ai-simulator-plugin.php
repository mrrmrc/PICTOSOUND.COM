<?php
/**
 * Plugin Name:       AI Compatibility Simulator
 * Description:       Aggiunge uno shortcode [ai_simulator] per analizzare la compatibilità di un sito con i sistemi AI.
 * Version:           1.0
 * Author:            La Tua AI
 */

// Impedisce l'accesso diretto al file
if (!defined('ABSPATH')) {
    exit;
}

/**
 * 1. Registra lo shortcode [ai_simulator]
 * Questa funzione genera l'HTML per il form e i contenitori dei risultati.
 */
function ai_simulator_shortcode_html() {
    // Carica gli stili e gli script solo quando lo shortcode è usato
    ai_simulator_enqueue_assets();

    ob_start(); // Inizia a catturare l'output HTML
    ?>
    <div class="ai-simulator-container">
        <header>
            <h1>🤖 Simulatore di Compatibilità AI</h1>
            <p>Scopri come un'Intelligenza Artificiale interpreterebbe i contenuti del tuo sito web.</p>
        </header>

        <main>
            <form id="ai-form">
                <?php wp_nonce_field('ai_simulator_nonce', 'ai_simulator_nonce_field'); ?>
                <div class="form-group">
                    <label for="url">URL della pagina da analizzare</label>
                    <input type="url" id="url" name="url" placeholder="https://www.esempio.it/pagina" required>
                </div>
                <div class="form-group">
                    <label for="query">Qual è la tua domanda?</label>
                    <input type="text" id="query" name="query" placeholder="Es: Quali sono gli orari di apertura?" required>
                </div>
                <button type="submit" id="submit-button">Analizza Ora</button>
            </form>

            <div id="loader" class="hidden">
                <div class="spinner"></div>
                <p>Analisi in corso... potrebbe richiedere qualche secondo.</p>
            </div>

            <div id="results-container" class="hidden">
                <h2>Risultati dell'Analisi</h2>
                <div class="result-box score">
                    <h3>Punteggio di Compatibilità AI</h3>
                    <div id="ai-score">0%</div>
                </div>
                <div class="result-box response">
                    <h3>Risposta Simulata dall'AI</h3>
                    <p id="simulated-response"></p>
                </div>
                <div class="result-box diagnostics">
                    <h3>Diagnosi Tecnica</h3>
                    <ul id="diagnostics-list"></ul>
                </div>
            </div>
             <div id="error-container" class="hidden">
                <h3>⚠️ Si è verificato un errore</h3>
                <p id="error-message"></p>
            </div>
        </main>
    </div>
    <?php
    return ob_get_clean(); // Restituisce l'HTML catturato
}
add_shortcode('ai_simulator', 'ai_simulator_shortcode_html');

/**
 * 2. Carica CSS e JavaScript necessari
 * Questo codice viene eseguito solo sulle pagine che contengono lo shortcode.
 */
function ai_simulator_enqueue_assets() {
    ?>
    <style>
        .ai-simulator-container {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
            background-color: #fff;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
            padding: 30px 40px;
            margin: 40px 0;
            max-width: 700px;
        }
        .ai-simulator-container header { text-align: center; margin-bottom: 30px; border-bottom: 1px solid #e0e0e0; padding-bottom: 20px; }
        .ai-simulator-container header h1 { font-size: 28px; margin: 0; color: #1a237e; }
        .ai-simulator-container header p { font-size: 16px; color: #555; margin-top: 8px; }
        .ai-simulator-container .form-group { margin-bottom: 20px; }
        .ai-simulator-container .form-group label { display: block; font-weight: bold; margin-bottom: 8px; font-size: 14px; }
        .ai-simulator-container .form-group input { width: 100%; padding: 12px; border: 1px solid #ccc; border-radius: 8px; font-size: 16px; box-sizing: border-box; }
        .ai-simulator-container button { width: 100%; padding: 15px; background-color: #1a237e; color: #fff; border: none; border-radius: 8px; font-size: 18px; font-weight: bold; cursor: pointer; transition: background-color 0.3s; }
        .ai-simulator-container button:hover { background-color: #283593; }
        .ai-simulator-container .hidden { display: none !important; }
        .ai-simulator-container #loader { text-align: center; margin-top: 30px; }
        .ai-simulator-container .spinner { border: 6px solid #f3f3f3; border-top: 6px solid #1a237e; border-radius: 50%; width: 50px; height: 50px; animation: spin 1s linear infinite; margin: 0 auto 15px auto; }
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
        .ai-simulator-container #results-container, .ai-simulator-container #error-container { margin-top: 40px; }
        .ai-simulator-container .result-box { background-color: #f9f9f9; border: 1px solid #e0e0e0; border-radius: 8px; padding: 20px; margin-bottom: 20px; }
        .ai-simulator-container .result-box h3 { margin-top: 0; border-bottom: 1px solid #ccc; padding-bottom: 10px; margin-bottom: 15px; color: #1a237e; }
        .ai-simulator-container #ai-score { font-size: 48px; font-weight: bold; text-align: center; color: #1a237e; }
        .ai-simulator-container #simulated-response { font-size: 16px; line-height: 1.6; }
        .ai-simulator-container #diagnostics-list { list-style-type: none; padding: 0; }
        .ai-simulator-container #diagnostics-list li { padding: 8px 0; border-bottom: 1px solid #eee; }
        .ai-simulator-container #diagnostics-list li:last-child { border-bottom: none; }
        .ai-simulator-container #error-container { background-color: #ffebee; border: 1px solid #c62828; color: #c62828; border-radius: 8px; padding: 20px; }
    </style>

    <script>
    document.addEventListener('DOMContentLoaded', () => {
        const form = document.getElementById('ai-form');
        if (!form) return;

        const loader = document.getElementById('loader');
        const resultsContainer = document.getElementById('results-container');
        const errorContainer = document.getElementById('error-container');
        const submitButton = document.getElementById('submit-button');

        form.addEventListener('submit', (event) => {
            event.preventDefault();

            const url = document.getElementById('url').value;
            const query = document.getElementById('query').value;
            const nonce = document.getElementById('ai_simulator_nonce_field').value;

            resultsContainer.classList.add('hidden');
            errorContainer.classList.add('hidden');
            loader.classList.remove('hidden');
            submitButton.disabled = true;
            submitButton.textContent = 'Analisi in corso...';

            const formData = new FormData();
            formData.append('action', 'analyze_ai_compatibility');
            formData.append('url', url);
            formData.append('query', query);
            formData.append('nonce', nonce);

            fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                method: 'POST',
                body: formData,
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    displayResults(data.data);
                } else {
                    displayError(data.data.message);
                }
            })
            .catch(error => {
                displayError('Si è verificato un errore di comunicazione con il server.');
            })
            .finally(() => {
                loader.classList.add('hidden');
                submitButton.disabled = false;
                submitButton.textContent = 'Analizza Ora';
            });
        });

        function displayResults(data) {
            document.getElementById('ai-score').textContent = `${data.aiScore}%`;
            document.getElementById('simulated-response').textContent = data.simulatedResponse;
            
            const diagnosticsList = document.getElementById('diagnostics-list');
            diagnosticsList.innerHTML = '';
            data.diagnostics.forEach(item => {
                const li = document.createElement('li');
                li.textContent = item;
                diagnosticsList.appendChild(li);
            });

            resultsContainer.classList.remove('hidden');
        }

        function displayError(message) {
            document.getElementById('error-message').textContent = message;
            errorContainer.classList.remove('hidden');
        }
    });
    </script>
    <?php
}

/**
 * 3. Gestisce la chiamata AJAX
 * Questa è la logica del backend che esegue l'analisi.
 */
function ai_simulator_ajax_handler() {
    // Sicurezza: controlla il nonce
    if (!check_ajax_referer('ai_simulator_nonce', 'nonce', false)) {
        wp_send_json_error(['message' => 'Controllo di sicurezza fallito.'], 403);
        wp_die();
    }

    $url = isset($_POST['url']) ? esc_url_raw($_POST['url']) : '';
    $query = isset($_POST['query']) ? strtolower(sanitize_text_field($_POST['query'])) : '';

    if (!filter_var($url, FILTER_VALIDATE_URL) || empty($query)) {
        wp_send_json_error(['message' => 'URL non valido o query mancante.'], 400);
        wp_die();
    }
    
    // Usa le funzioni HTTP di WordPress per la chiamata esterna
    $response = wp_remote_get($url, ['timeout' => 15, 'user-agent' => 'AIOptimizerBot-WP/1.0']);

    if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) {
        wp_send_json_error(['message' => 'Impossibile recuperare il contenuto dall\'URL.'], 500);
        wp_die();
    }

    $html = wp_remote_retrieve_body($response);

    // --- Inizio Analisi (Logica identica a prima) ---
    $score = 0;
    $max_score = 100;
    $diagnostics = [];
    $simulatedResponse = "Non sono riuscito a trovare una risposta chiara alla tua domanda.";

    $doc = new DOMDocument();
    libxml_use_internal_errors(true);
    $doc->loadHTML('<?xml encoding="UTF-8">' . $html); // Aggiungi encoding per robustezza
    libxml_clear_errors();
    $xpath = new DOMXPath($doc);

    $query_keywords = explode(' ', $query);

    $titleNode = $xpath->query('//title')->item(0);
    if ($titleNode && stripos($titleNode->textContent, $query) !== false) {
        $score += 10; $diagnostics[] = "✅ Il titolo della pagina è pertinente alla domanda.";
    }

    $metaDescNode = $xpath->query('//meta[@name="description"]/@content')->item(0);
    if ($metaDescNode && stripos($metaDescNode->value, $query) !== false) {
        $score += 15; $diagnostics[] = "✅ La meta description contiene parole chiave pertinenti.";
        $simulatedResponse = "La descrizione della pagina suggerisce: " . $metaDescNode->value;
    }

    $headings = $xpath->query('//h1|//h2');
    foreach ($headings as $heading) {
        if (stripos($heading->textContent, $query) !== false) {
            $score += 30; $diagnostics[] = "✅ Trovata corrispondenza in un\'intestazione importante (H1/H2).";
            $next_p = $xpath->query('following-sibling::p[1]', $heading)->item(0);
            if ($next_p) { $simulatedResponse = trim($next_p->textContent); }
            break;
        }
    }
    
    $jsonLdNodes = $xpath->query('//script[@type="application/ld+json"]');
    if ($jsonLdNodes->length > 0) {
        $diagnostics[] = "✅ La pagina utilizza dati strutturati (Schema.org)!";
        foreach($jsonLdNodes as $node) {
            if (stripos($node->textContent, $query) !== false) {
                $score += 45; $diagnostics[] = "✅ I dati strutturati contengono informazioni pertinenti!";
                 $data = json_decode($node->textContent, true);
                 if (json_last_error() === JSON_ERROR_NONE && stripos($query, 'orar') !== false && isset($data['openingHours'])) {
                     $simulatedResponse = "Secondo i dati strutturati, gli orari sono: " . (is_array($data['openingHours']) ? implode(', ', $data['openingHours']) : $data['openingHours']);
                 }
                break;
            }
        }
    } else {
         $diagnostics[] = "❌ Dati strutturati (JSON-LD) non trovati. Grande opportunità persa.";
    }
    
    // Fine Analisi

    $final_score = min(100, intval(($score / $max_score) * 100));

    $output = [
        'aiScore'           => $final_score,
        'simulatedResponse' => $simulatedResponse,
        'diagnostics'       => $diagnostics,
    ];

    wp_send_json_success($output); // Invia la risposta JSON in modo corretto
    wp_die(); 
}
// Aggancia la funzione all'hook AJAX di WordPress (per utenti loggati e non)
add_action('wp_ajax_analyze_ai_compatibility', 'ai_simulator_ajax_handler');
add_action('wp_ajax_nopriv_analyze_ai_compatibility', 'ai_simulator_ajax_handler');